exports.getProfile = (req, res) => {
  res.json({ message: `Welcome user with role: ${req.user.role}` });
};

exports.adminPanel = (req, res) => {
  res.json({ message: 'Welcome Admin!' });
};

exports.dashboard = (req, res) => {
  res.json({ message: 'Welcome Admin or Owner!' });
};