const express = require('express');
const { getProfile, adminPanel, dashboard } = require('../controllers/userController');
const { authenticateToken, authorizeRoles } = require('../middleware/authMiddleware');
const router = express.Router();

router.get('/profile', authenticateToken, getProfile);
router.get('/admin', authenticateToken, authorizeRoles('admin'), adminPanel);
router.get('/dashboard', authenticateToken, authorizeRoles('admin', 'owner'), dashboard);

module.exports = router;